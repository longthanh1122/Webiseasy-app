<!-- Footer -->
    <hr>
    <footer>
        <div class="row">
            <div class="col-md-12">
                <p class="text-center">Copyright &copy; Your Website 2017</p>
            </div>
        </div>
    </footer>
<!-- End Footer -->